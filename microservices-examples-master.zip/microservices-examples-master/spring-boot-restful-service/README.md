This project is a RESTful web service implemented using [Spring Boot](http://projects.spring.io/spring-boot/).
It is the example code for the article [Building microservices with Spring Boot - part 1](http://plainoldobjects.com/2014/04/01/building-microservices-with-spring-boot-part1/).

To build and test this web application, please see the instructions in the parent README.md.
