This project is a web application implemented using [Spring Boot](http://projects.spring.io/spring-boot/).
It's the example code for the article [Building microservices with Spring Boot - part 2](http://plainoldobjects.com/2014/05/05/building-microservices-with-spring-boot-part-2/).

To build and test this web application, please see the instructions in the parent README.md.
