package net.chrisrichardson.microservices.restfulspringboot.backend

/**
  * Created by cer on 5/30/16.
  */
case class RegistrationBackendRequest(emailAddress: String, password: String)
